function [X]=Shuffle_this_data(shuffle_p,X)
%% Shuffle the data
X=X(shuffle_p,:);

