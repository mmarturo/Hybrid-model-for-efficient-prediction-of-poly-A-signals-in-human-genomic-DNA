function A=NO_T(B)
[M,N]=size(B);

Mh=M/2;
A=B(:,1:end-1); 
